/*insert into users (name,password,email,nickname,location1,join_date,about_me,profile_content,intereds_langauage,intereds_framwork,intereds_job)
values ("김가영", "1234", "abc@gmail.com", "김별명", "서울", "2023-11-06 00:00:00", "한줄소개", "이력관리 들어갈 내용입니다.","_1_", "_1_", "_1_");
*/